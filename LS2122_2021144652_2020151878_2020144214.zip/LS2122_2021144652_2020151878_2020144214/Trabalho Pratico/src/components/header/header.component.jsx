function Header () {

    return (
        <header>
            <h1 className="title">Sopa de Letras</h1>
        </header>
    )

}

export default Header;