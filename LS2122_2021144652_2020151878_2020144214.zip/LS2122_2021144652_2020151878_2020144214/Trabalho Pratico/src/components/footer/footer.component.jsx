function Footer () {

    return (
        <p>@DEIS - Linguagens Script</p>
    )

}

export default Footer;